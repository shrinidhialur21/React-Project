
import './App.css';

// import HomePagesl from './components/HomePagesl';
// import Navbar from './components/Navbar';

function App() {
  return (
    <div className="App">
      <>
      
      </>
      
    </div>
  );
}

export default App;
