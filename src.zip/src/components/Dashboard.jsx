// import "../components/hstyle.css"
import { Link } from "react-router-dom"
import "../components/Dashboard.css"


const Dashboard = () => {

return (
    <div className="intro">
        <>
        {/* <h1>Hello there</h1> */}
        {/* <img className="Himage"   src='https://revolutionized.com/wp-content/uploads/sites/5/2022/05/rocket-launch-at-sunset.jpg' alt="ri"/> */}
        <div className="content1">
    <p>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book.
        </p>
        <form>
          {/* <input type="text" placeholder="Country Name" /> */}
          <button  className="btn">
            <Link  style={{textDecoration: 'none', color :'Black'}}  to={'/Rocket'}>Book Now!</Link>
          </button>
        </form>

    </div>

        </>
    </div>
)
}

export default Dashboard


