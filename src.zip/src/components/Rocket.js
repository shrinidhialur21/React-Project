import React from 'react'
import { useState,useEffect } from 'react'
import axios from 'axios';
import "../components/rocket.css"

function Rocket() {
  const [Info, setInfo] = useState([]);

  useEffect(() => {
    axios
      .get("https://api.spacexdata.com/v3/launches")
      // .then(Response => console.log("------------",Response))
      .then((e) => setInfo(e.data))

      .catch((err) => console.log("err...", err));
  }, []);

  console.log("Info....", Info);
  return (
    <div><h1>Rockets</h1></div>
  )
}

export default Rocket;