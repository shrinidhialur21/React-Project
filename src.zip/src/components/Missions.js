import React from 'react'
import { useState,useEffect } from 'react'
import axios from 'axios';
import "../components/missions.css"

function Missions() {

  const [Info, setInfo] = useState([]);

  useEffect(() => {
    axios
      .get("https://api.spacexdata.com/v3/launches")
      // .then(Response => console.log("------------",Response))
      .then((e) => setInfo(e.data))

      .catch((err) => console.log("err...", err));
  }, []);

  console.log("Info....", Info);
  return (
    
    <div className='Cont3'>
      <h1>Missions</h1>
      <table className='table2'> 
      <tr>
        <th>Mission Name</th>
        <th>Mission-ID</th>
        <th>rocket_id</th>
        <th>Launch Site</th>
      </tr>
      {Info.map((Object , index)=>{
        return(
          
          <tr>
              {/* <td>{Object.mission_name}</td> */}
              <td>{Object.mission_name === "" ? "NA" :Object.mission_name}</td>
              <td>{Object.mission_id.length === 0 ? "NA" :Object.mission_id}</td>
              <td>{Object.rocket.rocket_id}</td>
              <td>{Object.launch_site.site_name_long}</td>
            </tr>

        )
      })}
      </table>
    
    
    </div>
  )
}

export default Missions