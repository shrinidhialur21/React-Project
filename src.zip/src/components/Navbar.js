import React from "react";
import "../components/hstyle.css";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div className="cont">
    <nav className="nav">
      <h1>Stellar Launcher</h1>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/Launch">Launches</Link>
        </li>
        <li>
          <Link to="/Missions">Missions</Link>
        </li>
        <li>
          <Link to="/Payload">Payload</Link>
        </li>
        <li>
          <Link to="/Rocket">Rocket</Link>
        </li>
      </ul>
      
    </nav>
   
    </div>

  );
}




