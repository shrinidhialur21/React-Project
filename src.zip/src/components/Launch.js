import axios from "axios";
import React from "react";
import { useState, useEffect } from "react";
import "../components/Launch.css";

function Launch() {
  const [Info, setInfo] = useState([]);

  useEffect(() => {
    axios
      .get("https://api.spacexdata.com/v3/launches")
      // .then(Response => console.log("------------",Response))
      .then((e) => setInfo(e.data))

      .catch((err) => console.log("err...", err));
  }, []);

  console.log("Info....", Info);

  return (
    <div className="Cont2">
      <h1>Launches</h1>
      <table className="table">
      <tr>
              <th>Flight Number</th>
              <th>Mission Name</th>
              <th>Param</th>
              <th>Launch Date(Local Time)</th>
            </tr>
      {Info.map((Object, index) => {
        return (
        
            
            <tr>
              <td>{Object.flight_number}</td>
              <td>{Object.mission_name}</td>
              <td>{Object.rocket.rocket_id}</td>
              <td>{Object.launch_date_local}</td>
            </tr>

      
        );
      })}
      </table>
    </div>
    
  );
}

export default Launch;
