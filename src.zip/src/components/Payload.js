import React from 'react'
import { useState,useEffect } from 'react'
import axios from 'axios';
import "../components/missions.css"

function Payload() {
  const [Info, setInfo] = useState([]);

  useEffect(() => {
    axios
      .get("https://api.spacexdata.com/v3/payloads")
      // .then(Response => console.log("------------",Response))
      .then((e) => setInfo(e.data))

      .catch((err) => console.log("err...", err));
  }, []);

  console.log("Info....", Info);
  return (
    <div className='Cont3'>
    <h1>Payload</h1>
    <table className='table2'> 
    <tr>
      <th>Payload-ID</th>
      <th>Manufacturer</th>
      <th>Payload Type</th>
      <th>payload_mass_kg</th>
      <th>Nationality</th>
    </tr>
    {Info.map((Object , index)=>{
      return(
        
        <tr>
            {/* <td>{Object.mission_name}</td> */}
            <td>{Object.payload_id}</td>
            <td>{Object.manufacturer}</td>
            <td>{Object.payload_type}</td>
            <td>{Object.payload_mass_kg == null ? "NA": Object.payload_mass_kg}</td>
            <td>{Object.nationality}</td>
          </tr>

      )
    })}
    </table>
  
  
  </div>
    
  )
}

export default Payload